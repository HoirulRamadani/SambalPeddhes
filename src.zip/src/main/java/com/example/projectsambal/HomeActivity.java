package com.example.projectsambal;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        getSupportActionBar().hide();
    }
    public void kontak(View view){
        Intent intent = new Intent(HomeActivity.this, KontakActivity.class);
        startActivity(intent);
        finish();
    }
    public void profil(View view){
        Intent intent = new Intent(HomeActivity.this, ProfilActivity.class);
        startActivity(intent);
        finish();
    }
    public void pesan(View view){
        String linkwa = "https://wa.me/+6287850139793?text=Hi, Saya mau pesan";
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(linkwa));
        startActivity(intent);
    }
    public void onBackPressed(){
        new AlertDialog.Builder(this)
                .setTitle("Keluar")
                .setMessage("Apakah anda ingin keluar?")
                .setIcon(R.drawable.exit)
                .setPositiveButton("Iya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .show();
    }
}