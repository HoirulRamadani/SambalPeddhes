package com.example.projectsambal;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ProfilActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profil);
        getSupportActionBar().hide();
    }
    public void home(View view){
        Intent intent = new Intent(ProfilActivity.this, HomeActivity.class);
        startActivity(intent);
        finish();
    }
    public void kontak(View view){
        Intent intent = new Intent(ProfilActivity.this, KontakActivity.class);
        startActivity(intent);
        finish();
    }
    public void logout(View view){
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Apakah anda ingin logout?")
                .setIcon(R.drawable.logout)
                .setPositiveButton("Iya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(ProfilActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }
                })
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .show();
    }
    public void onBackPressed(){
        new AlertDialog.Builder(this)
                .setTitle("Keluar")
                .setMessage("Apakah anda ingin keluar?")
                .setIcon(R.drawable.exit)
                .setPositiveButton("Iya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .show();
    }
}