package com.example.projectsambal;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText eNama, eSandi;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        getSupportActionBar().hide();
        eNama = (EditText) findViewById(R.id.editNama);
        eSandi = (EditText) findViewById(R.id.editSandi);
    }
    public void login(View view){
        if(eNama.getText().toString().equals("Kagura") && eSandi.getText().toString().equals("12345678")){
            Toast.makeText(getApplicationContext(), "Login berhasil", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            LoginActivity.this.startActivity(intent);
            finish();
        }
        else if(eNama.getText().toString().equals("Hayabusa") && eSandi.getText().toString().equals("87654321")){
            Toast.makeText(getApplicationContext(), "Login berhasil", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, AdminActivity.class);
            LoginActivity.this.startActivity(intent);
            finish();
        }
        else{
            new AlertDialog.Builder(this)
                    .setTitle("Login")
                    .setMessage("Username atau password salah!")
                    .setIcon(R.drawable.login)
                    .setNegativeButton("Coba lagi", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    })
                    .show();
        }
    }
    public void onBackPressed(){
        new AlertDialog.Builder(this)
                .setTitle("Keluar")
                .setMessage("Apakah anda ingin keluar?")
                .setIcon(R.drawable.exit)
                .setPositiveButton("Iya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .show();
    }
}